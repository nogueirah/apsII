package dao;

import classes.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ClienteDAO {

    public String cadastrarCli(Cliente cliente) {
        String resp = "";

        try {
            Connection con = Conecta.getConexao();
            String sql = "INSERT INTO cliente(id_tipo_cliente, bloqueado, pcd, emailCli, senhaCli,"
                    + " nomeCli, cpfCli, celularCli) values(?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setBoolean(2, false);
            ps.setBoolean(3, cliente.isPcd());
            ps.setString(4, cliente.getEmailCli());
            ps.setString(5, cliente.getSenhaCli());
            ps.setString(6, cliente.getNomeCli());
            ps.setString(7, cliente.getCpfCli());
            ps.setString(8, cliente.getCelularCli());

            ps.execute();

            ps.close();

            con.close();

            resp = "Inserido";

        } catch (Exception e) {
            resp = "Erro: " + e.toString();
        }

        return resp;

    }

    public Cliente loginCli(Cliente cliente) {
        Cliente cli = new Cliente();
        String resp = "";

        try {
            Connection con = Conecta.getConexao();
            String sql = "select * from cliente where emailCli=? and senhaCli=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, cliente.getEmailCli());
            ps.setString(2, cliente.getSenhaCli());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                cli.setId_cliente(Integer.parseInt(rs.getString("id_cliente")));
                cli.setEmailCli(rs.getString("emailCli"));
                cli.setSenhaCli(rs.getString("senhaCli"));
                cli.setCpfCli(rs.getString("cpfCli"));
                cli.setNomeCli(rs.getString("nomeCli"));
                cli.setCelularCli(rs.getString("celularCli"));
                resp = "ok";
            } else {
                cli.setEmailCli("invalido");
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            resp = "k";

        }
        return cli;
    }

    public ArrayList<Cliente> getLista(String pesquisa) {
        ArrayList<Cliente> lista = new ArrayList<Cliente>();
        try {
            Connection con = Conecta.getConexao();
            String sql = "SELECT * FROM cliente WHERE cpfCli LIKE ? ORDER BY nomeCli";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + pesquisa + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.setNomeCli(rs.getString("nomeCli"));
                cli.setCpfCli(rs.getString("cpfCli"));
                cli.setEmailCli(rs.getString("emailCli"));
                cli.setCelularCli(rs.getString("celularCli"));
                cli.setBloqueado(rs.getBoolean("bloqueado"));
                cli.setId_tipo_cli(rs.getInt("id_tipo_cliente"));
                cli.setSenhaCli(rs.getString("senhaCli"));
                lista.add(cli);
            }
            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public String editCliC(Cliente cli) {
        String resp = "";
        try {
            Connection con = Conecta.getConexao();
            String sql = "UPDATE cliente set nomeCli=?, emailCli=?, senhaCli=?, celularCli=? WHERE id_cliente = ?";
            PreparedStatement ps = con.prepareStatement(sql);

            
            ps.setString(1, cli.getNomeCli());
            ps.setString(2, cli.getEmailCli());
            ps.setString(3, cli.getSenhaCli());
            ps.setString(4, cli.getCelularCli());
            ps.setInt(5, cli.getId_cliente());

            ps.execute();
            ps.close();
            con.close();

            resp = "ok";

        } catch (Exception e) {
            resp = "erro";

        }
        return resp;
    }

    public Cliente getCli(String pesquisa) {
        Cliente cli = new Cliente();
        try {
            Connection con = Conecta.getConexao();
            String sql = "SELECT * FROM cliente WHERE cpfCli =?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, pesquisa);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {

                cli.setNomeCli(rs.getString("nomeCli"));
                cli.setCpfCli(rs.getString("cpfCli"));
                cli.setEmailCli(rs.getString("emailCli"));
                cli.setCelularCli(rs.getString("celularCli"));
                cli.setBloqueado(rs.getBoolean("bloqueado"));
                cli.setId_tipo_cli(rs.getInt("id_tipo_cliente"));
                cli.setSenhaCli(rs.getString("senhaCli"));
                cli.setId_cliente(rs.getInt("id_cliente"));

            }
            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cli;
    }
    
    public String editCliF(Cliente cli){
        String resp = "";
        try {
            Connection con = Conecta.getConexao();
            String sql = "UPDATE cliente set nomeCli=?, emailCli=?, senhaCli=?, celularCli=?, bloqueado=?, "
                    + "pcd=?, id_tipo_cliente=?, cpfCli=? WHERE id_cliente = ?";
            PreparedStatement ps = con.prepareStatement(sql);

            
            ps.setString(1, cli.getNomeCli());
            ps.setString(2, cli.getEmailCli());
            ps.setString(3, cli.getSenhaCli());
            ps.setString(4, cli.getCelularCli());
            ps.setBoolean(5, cli.isBloqueado());
            ps.setBoolean(6, cli.isPcd());
            ps.setInt(7, cli.getId_tipo_cli());
            ps.setString(8, cli.getCpfCli());                                    
            ps.setInt(9, cli.getId_cliente());

            ps.execute();
            ps.close();
            con.close();

            resp = "ok";

        } catch (Exception e) {
            resp = "erro";

        }
        return resp;
    }
    
    public int getMensalistas(){
        int qtdMens = 0;
        try{
            Connection con = Conecta.getConexao();
            String sql = "SELECT * FROM cliente WHERE id_tipo_cliente = 2";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                qtdMens++;
            }
            
            rs.close();
            ps.close();
            con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return qtdMens;
    }

    public int getId(String cpf){
        int id = 999999;
        try{
            Connection con = Conecta.getConexao();
            String sql = "SELECT id_cliente FROM cliente WHERE cpfCli="+cpf;
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                id = rs.getInt("id_cliente");
            }
        }catch(Exception e){
            e.printStackTrace();
            
        }
        return id;
    }
}
