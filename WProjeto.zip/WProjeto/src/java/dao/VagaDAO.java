package dao;

import classes.Vaga;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class VagaDAO {

    public void setVagas(int n, int nPcd) {
        try {
            Connection con = Conecta.getConexao();
            String sql = "TRUNCATE TABLE vaga";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.execute();
            ps.close();
            for (int i = 0; i < nPcd; i++) {
                sql = "INSERT INTO vaga(status_vaga, tipo_vaga) values ('Disponível', 'PCD')";
                ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();

            }
            for (int i = 0; i < n; i++) {
                sql = "INSERT INTO vaga(status_vaga, tipo_vaga) values ('Disponível', 'Comum')";
                ps = con.prepareStatement(sql);
                ps.execute();
                ps.close();

            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public ArrayList<Vaga> getLista() {
        ArrayList<Vaga> lista = new ArrayList<Vaga>();
        try {
            Connection con = Conecta.getConexao();
            String sql = "SELECT * FROM vaga";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Vaga v = new Vaga();
                v.setId(rs.getInt("id_vaga"));
                v.setStatus(rs.getString("status_vaga"));
                v.setTipo(rs.getString("tipo_vaga"));
                lista.add(v);
            }
            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public Vaga getVaga(int id) {
        Vaga v = new Vaga();
        try {
            Connection con = Conecta.getConexao();
            String sql = "select * from vaga where id_vaga=" + id;
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                v.setStatus(rs.getString("status_vaga"));
                v.setTipo(rs.getString("tipo_vaga"));
                v.setId(rs.getInt("id_vaga"));
            }
            ps.execute();
            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return v;
    }

    public String ocupaVaga(Vaga v) {
        String resp = "";
        try {
            Connection con = Conecta.getConexao();
            String sql = "UPDATE vaga set status_vaga=? WHERE id_vaga = ?";
            PreparedStatement ps = con.prepareStatement(sql);

            
            ps.setString(1, v.getStatus());           
            ps.setInt(2, v.getId());

            ps.execute();
            ps.close();
            con.close();

            resp = "ok";

        } catch (Exception e) {
            resp = "erro";

        }
        return resp;
    }
    public String liberaVaga(int id) {
        String resp = "";
        try {
            Connection con = Conecta.getConexao();
            String sql = "UPDATE vaga set status_vaga='Disponível' WHERE id_vaga ="+id;
            PreparedStatement ps = con.prepareStatement(sql);

            ps.execute();
            ps.close();
            con.close();

            resp = "ok";

        } catch (Exception e) {
            resp = "erro";

        }
        return resp;
    }
    
    public int contaVagas(){
        int vagas = 0;
        try {
            Connection con = Conecta.getConexao();
            String sql = "SELECT COUNT(status_vaga) as count from vaga WHERE status_vaga = 'Disponível' and tipo_vaga='Comum'";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {

                vagas = (rs.getInt("count"));
            }
            ps.execute();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();

        }
        return vagas;
    }

}
