package dao;

import classes.Estacionamento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EstacionamentoDAO {
    public Estacionamento pegarVagas(Estacionamento est){
        try{
            Connection con = Conecta.getConexao();
            String sql = "SELECT total_vagas FROM estacionamento";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                est.setVagas(rs.getInt("total_vagas"));
            }
            ps.close();
            rs.close();
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return est;
    }
    
    public String AlteraVagas(int vagas){
        String resp = "";
        try{
            Connection con = Conecta.getConexao();
            String sql = "UPDATE estacionamento SET total_vagas = " + vagas + " WHERE id_estacionamento = 1";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.execute();
            ps.close();
            con.close();
            resp = "ok";
        }catch(Exception e){
            resp = "erro";
        }
        return resp;
    }
}
