package dao;

import classes.Estacionamento;
import classes.TipoServico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TipoServicoDAO {
    
    public TipoServico getTipoServico(int id){
        TipoServico tipoServico = new TipoServico();
        try{
            
            Connection con = Conecta.getConexao();
            String sql = "SELECT * FROM tipo_servico where id_tipo_cliente=" + id;
            PreparedStatement ps = con.prepareStatement(sql);            
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                tipoServico.setId_tipo(rs.getInt("id_tipo_servico"));
                tipoServico.setId_tipo_cli(rs.getInt("id_tipo_cliente"));
                tipoServico.setValor_diario(rs.getFloat("valor_diario"));
                tipoServico.setValor_mensal(rs.getFloat("valor_mensal"));
                tipoServico.setDemais_horas(rs.getFloat("valor_demais_hora"));
                tipoServico.setAteUmaHora(rs.getFloat("ate_uma_hora"));
                tipoServico.setDescricao(rs.getString("desc_tipo_servico"));
            }
            ps.close();
            rs.close();
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return tipoServico;
    }
    
    public String salvarServico(TipoServico ts) {
        String resp = "";

        try {
            Connection con = Conecta.getConexao();
            String sql = "UPDATE tipo_servico SET id_tipo_servico=?, id_tipo_cliente=?, valor_diario=?, valor_mensal=?, "
                    + "valor_demais_hora=?, ate_uma_hora=?, desc_tipo_servico=? where id_tipo_servico = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, ts.getId_tipo());
            ps.setInt(2, ts.getId_tipo_cli());
            ps.setFloat(3, ts.getValor_diario());
            ps.setFloat(4, ts.getValor_mensal());
            ps.setFloat(5, ts.getDemais_horas());
            ps.setFloat(6, ts.getAteUmaHora());
            ps.setString(7, ts.getDescricao());
            ps.setInt(8, ts.getId_tipo());

            ps.execute();

            ps.close();

            con.close();

            resp = "Alterado";

        } catch (Exception e) {
            resp = "Erro: " + e.toString();
        }

        return resp;

    }
}
