package dao;

import classes.Reserva;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ReservaDAO {
    public String inserirReserva(Reserva r){
        String resp = "";

        try {
            Connection con = Conecta.getConexao();
            String sql = "INSERT INTO reserva(id_cliente, cpfCli, data_entrada) values(?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, r.getId_cliente());
            ps.setString(2, r.getCpfCli());
            ps.setDate(3, new java.sql.Date(r.getDataEntrada().getTime()));

            ps.execute();

            ps.close();

            con.close();

            resp = "Inserido";

        } catch (Exception e) {
            resp = "Erro: " + e.toString();
        }

        return resp;
    }
    
    public ArrayList<Reserva> getReservas() {
        ArrayList<Reserva> lista = new ArrayList<Reserva>();
        try {
            Connection con = Conecta.getConexao();
            String sql = "SELECT * FROM reserva WHERE data_entrada > DATE_SUB(NOW(), INTERVAL 24 HOUR) order by data_entrada";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Reserva r = new Reserva();
                r.setId_reserva(rs.getInt("id_reserva"));
                r.setId_cliente(rs.getInt("id_cliente"));
                r.setCpfCli(rs.getString("cpfCli"));
                r.setDataEntrada(rs.getDate("data_entrada"));
               
                lista.add(r);
            }
            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            System.out.println("ERRO: " + e.toString());
        }
        return lista;
        
    }
}
