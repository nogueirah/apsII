package dao;

import classes.Servico;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class ServicoDAO {
    
    public String setServico(Servico serv){
         String resp = "";

        try {
            Connection con = Conecta.getConexao();
            String sql = "INSERT INTO servico(placaCli, id_vaga, id_cliente, id_funcionario,"
                    + " id_tipo_servico, dh_entrada) values(?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, serv.getPlacaCli());
            ps.setInt(2, serv.getId_vaga());
            ps.setInt(3, serv.getId_cliente());
            ps.setInt(4, serv.getId_funcionario());
            ps.setInt(5, serv.getId_tipo_servico());
            ps.setTimestamp(6, new java.sql.Timestamp(new java.util.Date().getTime()));
            

            ps.execute();

            ps.close();

            con.close();

            resp = "Inserido";

        } catch (Exception e) {
            resp = "Erro: " + e.toString();
        }

        return resp;

    }
    
}

