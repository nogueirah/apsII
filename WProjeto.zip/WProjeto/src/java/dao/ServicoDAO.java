package dao;

import classes.Servico;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class ServicoDAO {
    
    public String setServico(Servico serv){
         String resp = "";

        try {
            Connection con = Conecta.getConexao();
            String sql = "INSERT INTO servico(placaCli, id_vaga, id_cliente, id_funcionario,"
                    + " id_tipo_servico, dh_entrada) values(?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setString(1, serv.getPlacaCli());
            ps.setInt(2, serv.getId_vaga());
            ps.setInt(3, serv.getId_cliente());
            ps.setInt(4, serv.getId_funcionario());
            ps.setInt(5, serv.getId_tipo_servico());
            ps.setTimestamp(6, new java.sql.Timestamp(new java.util.Date().getTime()));
            

            ps.execute();

            ps.close();

            con.close();

            resp = "Inserido";

        } catch (Exception e) {
            resp = "Erro: " + e.toString();
        }

        return resp;

    }
    
    public Servico getServico(String placa){
        Servico s = new Servico();
        try{
            Connection con = Conecta.getConexao();
            String sql = "SELECT * FROM servico WHERE placaCli = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, placa);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                s.setId_servico(rs.getInt("id_servico"));
                s.setPlacaCli(rs.getString("placaCli"));
                s.setId_vaga(rs.getInt("id_vaga"));
                s.setId_cliente(rs.getInt("id_cliente"));
                s.setId_funcionario(rs.getInt("id_funcionario"));
                s.setId_tipo_servico(rs.getInt("id_tipo_servico"));
                s.setDh_entrada(rs.getDate("dh_entrada"));
                s.setDh_saida(new java.sql.Timestamp(new java.util.Date().getTime()));
            }
            
            ps.close();
            rs.close();
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return s;
    }
    
    public String updateServico(Servico serv){
         String resp = "";

        try {
            Connection con = Conecta.getConexao();
            String sql = "update servico set dh_saida=? where id_servico=?";
            PreparedStatement ps = con.prepareStatement(sql);
            
            ps.setTimestamp(1, serv.getDh_saida());
            ps.setInt(2, serv.getId_servico());
            

            ps.execute();

            ps.close();

            con.close();

            resp = "ok";

        } catch (Exception e) {
            resp = "Erro: " + e.toString();
        }

        return resp;

    }
    
    public int getHoras(int id){
        int horas = 0;
        try{
            Connection con = Conecta.getConexao();
            String sql = "select timestampdiff(hour, dh_entrada, dh_saida) as horas from servico where id_servico = " + id;
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                horas = rs.getInt("horas");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return horas;
    }
    
    
    
}

