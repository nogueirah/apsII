package classes;

public class TipoServico {
    private int id_tipo;
    private int id_tipo_cli;
    private float valor_diario;
    private float valor_mensal;
    private float demais_horas;
    private float ateUmaHora;
    private String descricao;

    /**
     * @return the id_tipo
     */
    public int getId_tipo() {
        return id_tipo;
    }

    /**
     * @param id_tipo the id_tipo to set
     */
    public void setId_tipo(int id_tipo) {
        this.id_tipo = id_tipo;
    }

    /**
     * @return the id_tipo_cli
     */
    public int getId_tipo_cli() {
        return id_tipo_cli;
    }

    /**
     * @param id_tipo_cli the id_tipo_cli to set
     */
    public void setId_tipo_cli(int id_tipo_cli) {
        this.id_tipo_cli = id_tipo_cli;
    }

    /**
     * @return the valor_diario
     */
    public float getValor_diario() {
        return valor_diario;
    }

    /**
     * @param valor_diario the valor_diario to set
     */
    public void setValor_diario(float valor_diario) {
        this.valor_diario = valor_diario;
    }

    /**
     * @return the valor_mensal
     */
    public float getValor_mensal() {
        return valor_mensal;
    }

    /**
     * @param valor_mensal the valor_mensal to set
     */
    public void setValor_mensal(float valor_mensal) {
        this.valor_mensal = valor_mensal;
    }

    /**
     * @return the demais_horas
     */
    public float getDemais_horas() {
        return demais_horas;
    }

    /**
     * @param demais_horas the demais_horas to set
     */
    public void setDemais_horas(float demais_horas) {
        this.demais_horas = demais_horas;
    }

    /**
     * @return the ateUmaHora
     */
    public float getAteUmaHora() {
        return ateUmaHora;
    }

    /**
     * @param ateUmaHora the ateUmaHora to set
     */
    public void setAteUmaHora(float ateUmaHora) {
        this.ateUmaHora = ateUmaHora;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
}
