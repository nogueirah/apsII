package classes;

import java.util.Date;

public class Reserva {
    private int id_reserva;
    private int id_cliente;
    private int id_servico;
    private String cpfCli;
    private Date dataEntrada;

    /**
     * @return the id_reserva
     */
    public int getId_reserva() {
        return id_reserva;
    }

    /**
     * @param id_reserva the id_reserva to set
     */
    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    /**
     * @return the id_cliente
     */
    public int getId_cliente() {
        return id_cliente;
    }

    /**
     * @param id_cliente the id_cliente to set
     */
    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    /**
     * @return the id_servico
     */
    public int getId_servico() {
        return id_servico;
    }

    /**
     * @param id_servico the id_servico to set
     */
    public void setId_servico(int id_servico) {
        this.id_servico = id_servico;
    }

    /**
     * @return the cpfCli
     */
    public String getCpfCli() {
        return cpfCli;
    }

    /**
     * @param cpfCli the cpfCli to set
     */
    public void setCpfCli(String cpfCli) {
        this.cpfCli = cpfCli;
    }

    /**
     * @return the dataEntrada
     */
    public Date getDataEntrada() {
        return dataEntrada;
    }

    /**
     * @param dataEntrada the dataEntrada to set
     */
    public void setDataEntrada(Date dataEntrada) {
        this.dataEntrada = dataEntrada;
    }
    
}
