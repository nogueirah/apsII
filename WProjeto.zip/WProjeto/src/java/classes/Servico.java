
package classes;

import java.sql.Date;

public class Servico {
    private int id_servico;
    private String placaCli;
    private int id_vaga;
    private int id_cliente;
    private int id_funcionario;
    private int id_tipo_servico;
    private Date dh_entrada;
    private Date dh_saida;

    /**
     * @return the id_servico
     */
    public int getId_servico() {
        return id_servico;
    }

    /**
     * @param id_servico the id_servico to set
     */
    public void setId_servico(int id_servico) {
        this.id_servico = id_servico;
    }

    /**
     * @return the placaCli
     */
    public String getPlacaCli() {
        return placaCli;
    }

    /**
     * @param placaCli the placaCli to set
     */
    public void setPlacaCli(String placaCli) {
        this.placaCli = placaCli;
    }

    /**
     * @return the id_vaga
     */
    public int getId_vaga() {
        return id_vaga;
    }

    /**
     * @param id_vaga the id_vaga to set
     */
    public void setId_vaga(int id_vaga) {
        this.id_vaga = id_vaga;
    }

    /**
     * @return the id_cliente
     */
    public int getId_cliente() {
        return id_cliente;
    }

    /**
     * @param id_cliente the id_cliente to set
     */
    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    /**
     * @return the id_funcionario
     */
    public int getId_funcionario() {
        return id_funcionario;
    }

    /**
     * @param id_funcionario the id_funcionario to set
     */
    public void setId_funcionario(int id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    /**
     * @return the id_tipo_servico
     */
    public int getId_tipo_servico() {
        return id_tipo_servico;
    }

    /**
     * @param id_tipo_servico the id_tipo_servico to set
     */
    public void setId_tipo_servico(int id_tipo_servico) {
        this.id_tipo_servico = id_tipo_servico;
    }

    /**
     * @return the dh_entrada
     */
    public Date getDh_entrada() {
        return dh_entrada;
    }

    /**
     * @param dh_entrada the dh_entrada to set
     */
    public void setDh_entrada(Date dh_entrada) {
        this.dh_entrada = dh_entrada;
    }

    /**
     * @return the dh_saida
     */
    public Date getDh_saida() {
        return dh_saida;
    }

    /**
     * @param dh_saida the dh_saida to set
     */
    public void setDh_saida(Date dh_saida) {
        this.dh_saida = dh_saida;
    }
}
