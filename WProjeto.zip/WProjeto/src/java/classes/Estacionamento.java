package classes;

public class Estacionamento {
    private int id_estcionamento;
    private String nome;
    private int vagas;

    /**
     * @return the id_estcionamento
     */
    public int getId_estcionamento() {
        return id_estcionamento;
    }

    /**
     * @param id_estcionamento the id_estcionamento to set
     */
    public void setId_estcionamento(int id_estcionamento) {
        this.id_estcionamento = id_estcionamento;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the vagas
     */
    public int getVagas() {
        return vagas;
    }

    /**
     * @param vagas the vagas to set
     */
    public void setVagas(int vagas) {
        this.vagas = vagas;
    }
    
}
