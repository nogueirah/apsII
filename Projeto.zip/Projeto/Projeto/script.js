
let div_va, j;
let cor =[]
function fazerdiv() {
        for ( j = 0; j < 60; j++) {
            div_va = document.createElement('div')
            div_va.setAttribute('class', 'vagas_d')
            div_va.setAttribute('id', `div_vaga${j}`)
            div_va.setAttribute("onclick", `ficar_vermelho('div_V${j}')`)
            document.getElementById("vagas").appendChild(div_va)
            cor[j] = 0
    }
}

function ficar_vermelho(nomediv) {
    for(let k=0;k<60;k++){
        if (nomediv == `div_V${k}`) {
            if (cor[k] == 0) {
                document.getElementById(`div_vaga${k}`).style.background = 'red'
                cor[k] =  1
            }else if(cor[k] == 1){
                document.getElementById(`div_vaga${k}`).style.background = '#fff'
                cor[k] = 0
            }
        }
    } 
}