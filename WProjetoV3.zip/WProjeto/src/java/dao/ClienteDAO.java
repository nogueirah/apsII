
package dao;

import classes.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ClienteDAO {
    
    public String cadastrarCli(Cliente cliente){
            String resp = "";

        try {
            Connection con = Conecta.getConexao();
                String sql = "INSERT INTO cliente(id_tipo_cliente, bloqueado, pcd, emailCli, senhaCli,"
                        + " nomeCli, cpfCli, celularCli) values(?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setBoolean(2, false);
            ps.setBoolean(3, cliente.isPcd());
            ps.setString(4, cliente.getEmailCli());
            ps.setString(5, cliente.getSenhaCli());
            ps.setString(6, cliente.getNomeCli());
            ps.setString(7, cliente.getCpfCli());
            ps.setString(8, cliente.getCelularCli());
          

            ps.execute();

            ps.close();

            con.close();

            resp = "Inserido";

        } catch (Exception e) {
            resp = "Erro: " + e.toString();
        }

        return resp;

    }
    
    public String loginCli(Cliente cliente){
         String resp = "";

        try {
            Connection con = Conecta.getConexao();
            String sql = "select * from cliente where emailCli=? and senhaCli=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, cliente.getEmailCli());
            ps.setString(2, cliente.getSenhaCli());
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()){
                cliente.setEmailCli(rs.getString("emailCli"));
                cliente.setSenhaCli(rs.getString("senhaCli"));
               
                 resp="ok";
            }
            
            
            
            rs.close();
            ps.close();
            con.close();
        
    } catch(Exception e){
        resp = "k";
    
}
        return resp;
    }
}

