package classes;


public class Funcionario {
    private String login;
    private String senha;
    private String nomeFun;
    private String cpfFun;
    private int id_endereco;
    private String celular;

    /**
     * @return the login
     */
    public String getLogin() {
        return login;
    }

    /**
     * @param login the login to set
     */
    public void setLogin(String login) {
        this.login = login;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the nomeFun
     */
    public String getNomeFun() {
        return nomeFun;
    }

    /**
     * @param nomeFun the nomeFun to set
     */
    public void setNomeFun(String nomeFun) {
        this.nomeFun = nomeFun;
    }

    /**
     * @return the cpfFun
     */
    public String getCpfFun() {
        return cpfFun;
    }

    /**
     * @param cpfFun the cpfFun to set
     */
    public void setCpfFun(String cpfFun) {
        this.cpfFun = cpfFun;
    }

    /**
     * @return the id_endereco
     */
    public int getId_endereco() {
        return id_endereco;
    }

    /**
     * @param id_endereco the id_endereco to set
     */
    public void setId_endereco(int id_endereco) {
        this.id_endereco = id_endereco;
    }

    /**
     * @return the celular
     */
    public String getCelular() {
        return celular;
    }

    /**
     * @param celular the celular to set
     */
    public void setCelular(String celular) {
        this.celular = celular;
    }
        
    
}
